### Terminal 1:
```bash
cd CS256/my-app
npm start
```
### Terminal 2:
```bash
ngrok killall
ngrok http 3000
```